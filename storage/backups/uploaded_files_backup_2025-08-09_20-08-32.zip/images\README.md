# G0-CAMPUS Sample Images

## Logo Sample
Mari gunakan logo text-based untuk testing:
- Logo: https://via.placeholder.com/200x80/4a90e2/ffffff?text=G0-CAMPUS

## Favicon Sample  
- Favicon: https://via.placeholder.com/32x32/4a90e2/ffffff?text=G0
